#pragma once
/*********************************************************************
 * @file    app_ui.h
 * @brief   Button1 ó�� �������̽�
 *********************************************************************/

void app_key_handler(void);
void localPermitJoinState(void);
