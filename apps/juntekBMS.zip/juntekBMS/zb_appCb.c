/*********************************************************************
 * @file    zb_appCb.c
 * @brief   Zigbee 스택 이벤트 콜백 — LED_POWER 상태 연동
 *
 * [수정] steer_retry_cb: 1회 종료 → 조인 성공까지 무한 반복
 *********************************************************************/
#include "tl_common.h"
#include "zb_api.h"
#include "zcl_include.h"
#include "bdb.h"
#include "ota.h"
#include "juntekMonitor.h"
#include "juntekCtrl.h"
#include "juntek_ep.h"
#include "factory_reset.h"

/*--------------------------------------------------------------------
 * JOIN 후 전체 EP 상태 보고 타이머
 *------------------------------------------------------------------*/
static s32 report_all_cb(void *arg)
{
//    u8 i;
//    u8 ep_list[] = {JUNTEK_ENDPOINT_ELEC,
//    		        JUNTEK_ENDPOINT_TEMP,
//    		        JUNTEK_ENDPOINT_RELAY};
//
//    for (i = 0; i < JUNTEK_EP_COUNT; i++) {
//        u8 ep  = ep_list[i];
//        u8 idx = i;
//        if (idx == 0xFF) continue;
//
//        /* broadcast로 전송 — Z2M이 수신하도록 */
//        epInfo_t dstEp;
//        TL_SETSTRUCTCONTENT(dstEp, 0);
//        dstEp.dstAddrMode       = APS_SHORT_DSTADDR_WITHEP;
//        dstEp.dstAddr.shortAddr = 0xFFFF;  /* broadcast */
//        dstEp.dstEp             = 0xFF;    /* broadcast EP */
//        dstEp.profileId         = HA_PROFILE_ID;
//        dstEp.txOptions         = 0;
//        dstEp.radius            = 0;
//
////        /* OnOff 보고 */
////        zcl_sendReportCmd(ep,
////        		         &dstEp,
////        		          FALSE,
////        		          ZCL_FRAME_SERVER_CLIENT_DIR,
////                          ZCL_CLUSTER_GEN_ON_OFF, ZCL_ATTRID_ONOFF,
////                          ZCL_DATA_TYPE_BOOLEAN, &g_zcl_onOffAttrs[idx].onOff);
////
////        /* Level 보고 */
////        zcl_sendReportCmd(ep,
////        		         &dstEp,
////        		          FALSE,
////        		          ZCL_FRAME_SERVER_CLIENT_DIR,
////                          ZCL_CLUSTER_GEN_LEVEL_CONTROL, ZCL_ATTRID_LEVEL_CURRENT_LEVEL,
////                          ZCL_DATA_TYPE_UINT8, &g_zcl_levelAttrs[idx].curLevel);
//    }
//
//
//

    //printf("report_all: done");
    return -1;
}

/*--------------------------------------------------------------------
 * Network Steering 재시도 타이머
 *------------------------------------------------------------------*/
static s32 steer_retry_cb(void *arg)
{
    if (zb_isDeviceJoinedNwk()) {
        //printf("BDB: already joined, stop retry\r\n");
        return -1;
    }
    //printf("BDB: retry steering\r\n");
    bdb_networkSteerStart();
    return 10000;
}

/*--------------------------------------------------------------------
 * bdbInitCb
 *------------------------------------------------------------------*/
static void zbdemo_bdbInitCb(u8 status, u8 joinedNetwork)
{
    printf("BDB init: status=%d joined=%d factoryNew=%d\r\n",
           status, joinedNetwork, zb_isDeviceFactoryNew());

    if (joinedNetwork) {
        led_power_set_state(LED_PWR_STATE_JOINED);
        TL_ZB_TIMER_SCHEDULE(report_all_cb, NULL, 3000);
    } else {
        led_power_set_state(LED_PWR_STATE_NOT_JOINED);
        printf("BDB: start steering\r\n");
        bdb_networkSteerStart();
    }
}

/*--------------------------------------------------------------------
 * bdbcommissioningCb
 *------------------------------------------------------------------*/
static void zbdemo_bdbCommissioningCb(u8 status, void *arg)
{
    printf("BDB commission: status=%d joined=%d\r\n", status, zb_isDeviceJoinedNwk());

    if (status == BDB_COMMISSION_STA_SUCCESS) {
        led_power_set_state(LED_PWR_STATE_JOINED);
        printf("BDB: Joined\r\n");
        TL_ZB_TIMER_SCHEDULE(report_all_cb, NULL, 2000);
    } else if (status == BDB_COMMISSION_STA_IN_PROGRESS) {
        /* 진행 중 */
    } else {
        led_power_set_state(LED_PWR_STATE_NOT_JOINED);
        printf("BDB: fail=%d, retry 10s\r\n", status);
        TL_ZB_TIMER_SCHEDULE(steer_retry_cb, NULL, 10000);
    }
}

/*--------------------------------------------------------------------
 * BDB 콜백 구조체
 *------------------------------------------------------------------*/
bdb_appCb_t g_zbDemoBdbCb = {
    zbdemo_bdbInitCb,
    zbdemo_bdbCommissioningCb,
    NULL,
    NULL,
};

/*--------------------------------------------------------------------
 * ZDO 네트워크 이벤트 콜백
 *------------------------------------------------------------------*/
void juntek_leaveIndHandler(nlme_leave_ind_t *pLeaveInd)
{
    led_power_set_state(LED_PWR_STATE_NOT_JOINED);
    printf("NWK: leave\r\n");
    TL_ZB_TIMER_SCHEDULE(steer_retry_cb, NULL, 3000);
}

void juntek_leaveCnfHandler(nlme_leave_cnf_t *pLeaveCnf)
{
    printf("NWK: leave cnf\r\n");
}

bool juntek_nwkUpdateIndicateHandler(nwkCmd_nwkUpdate_t *pNwkUpdate)
{
    return FALSE;
}

void juntek_nwkStatusIndHandler(zdo_nwk_status_ind_t *pNwkStatusInd)
{
    /* [수정] 기존 코드는 pNwkStatusInd 가 non-NULL 이면(거의 항상 참)
     * 무조건 LED_PWR_STATE_NOT_JOINED 로 되돌렸음.
     * NWK Status 알림은 정상 운영 중에도(라우팅 정보 등) 자주 발생하므로
     * join 직후 LED가 다시 깜빡이는 버그의 원인이었음.
     *
     * 실제로 네트워크에서 이탈한 상태인지(zb_isDeviceJoinedNwk() == FALSE)
     * 확인 후에만 LED를 NOT_JOINED 로 전환한다. */
    printf("NWK status ind: joined=%d\r\n", zb_isDeviceJoinedNwk());
    if (pNwkStatusInd && !zb_isDeviceJoinedNwk()) {
        led_power_set_state(LED_PWR_STATE_NOT_JOINED);
    }
}

/*--------------------------------------------------------------------
 * Rejoin 백오프
 *------------------------------------------------------------------*/
void juntek_rejoinBackoff(void)
{
    if (!zb_isDeviceFactoryNew()) {
        zb_rejoinSecModeSet(0);
        zb_rejoinReq(zb_apsChannelMaskGet(), 0);
    }
}

/*--------------------------------------------------------------------
 * Factory Reset LED
 *------------------------------------------------------------------*/
void zbdemo_factoryResetCb(void)
{
    led_power_set_state(LED_PWR_STATE_RESET);
}
